﻿Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Equipment
    Dim xlsmApp As New Excel.Application
    Dim xlsmWB1 As Excel.Workbook
    Dim xlsmWS1 As Excel.Worksheet
    Private Sub Equipment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'DataSet1.Equipment' table. You can move, or remove it, as needed.
        Me.EquipmentTableAdapter.Fill(Me.DataSet1.Equipment)
        'TODO: This line of code loads data into the 'DataSet1.Equipment' table. You can move, or remove it, as needed.
        Me.EquipmentTableAdapter.Fill(Me.DataSet1.Equipment)



    End Sub

    Private Sub EquipmentBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
     On Error GoTo ErrHandler

        Dim fileEquip As String = "Book1.xlsm"
        xlsmApp.Workbooks.Open(fileEquip)
        xlsmApp.Visible = True
        Exit Sub
ErrHandler:
        MsgBox("Error: Couldnt Open" & fileEquip, vbCritical, "Error")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'On Error GoTo ErrHandler

        Dim fileEquip As String = "Book1.xlsm"
        xlsmWB1 = xlsmApp.Workbooks.Open(fileEquip)
        xlsmApp.Visible = False
        xlsmWS1 = xlsmWB1.Worksheets("Sheet1")


        Dim excel_col As Integer = 1
        Dim excel_row As Integer
        Dim max_row As Integer = 805
        Dim max_col As Integer = 10
        Dim equip_list(max_row, max_col)
        'Reading the Excel file and putting everything in Memory for faster manipulation
        For excel_row = 2 To max_row Step 1

            Dim equip_row As DataRow = Me.DataSet1.Equipment.NewEquipmentRow

            equip_row("Part ID") = (excel_row)
            equip_row("Type") = xlsmWS1.Cells(excel_row, excel_col).Value
            equip_row("Description") = xlsmWS1.Cells(excel_row, excel_col + 1).Value
            equip_row("Model Number") = xlsmWS1.Cells(excel_row, excel_col + 2).Value
            equip_row("Serial Number") = xlsmWS1.Cells(excel_row, excel_col + 3).Value
            equip_row("Asset Number") = xlsmWS1.Cells(excel_row, excel_col + 4).Value
            equip_row("Manufacturer ID") = xlsmWS1.Cells(excel_row, excel_col + 5).Value
            equip_row("Department ID") = xlsmWS1.Cells(excel_row, excel_col + 6).Value
            equip_row("Location") = xlsmWS1.Cells(excel_row, excel_col + 7).Value
            equip_row("Last Calibration") = xlsmWS1.Cells(excel_row, excel_col + 8).Value
            equip_row("Calibration Due Date") = xlsmWS1.Cells(excel_row, excel_col + 9).Value

            equip_row("Section 4") = xlsmWS1.Cells(excel_row, excel_col + 9).Value
            equip_row("Section 5") = xlsmWS1.Cells(excel_row, excel_col + 10).Value
            equip_row("Section 6") = xlsmWS1.Cells(excel_row, excel_col + 11).Value
            equip_row("Section 7") = xlsmWS1.Cells(excel_row, excel_col + 12).Value
            equip_row("Section 8 ") = xlsmWS1.Cells(excel_row, excel_col + 13).Value
            equip_row("Section 9") = xlsmWS1.Cells(excel_row, excel_col + 14).Value
            equip_row("Section 10") = xlsmWS1.Cells(excel_row, excel_col + 15).Value

            equip_row("Section 11") = xlsmWS1.Cells(excel_row, excel_col + 16).Value
            equip_row("Section 12") = xlsmWS1.Cells(excel_row, excel_col + 17).Value
            equip_row("Section 13") = xlsmWS1.Cells(excel_row, excel_col + 18).Value
            equip_row("Section 14") = xlsmWS1.Cells(excel_row, excel_col + 19).Value
            equip_row("Section 15") = xlsmWS1.Cells(excel_row, excel_col + 20).Value

            equip_row("Section 16") = xlsmWS1.Cells(excel_row, excel_col + 21).Value
            equip_row("Section 17") = xlsmWS1.Cells(excel_row, excel_col + 22).Value
            equip_row("Section 18") = xlsmWS1.Cells(excel_row, excel_col + 23).Value
            equip_row("Section 19") = xlsmWS1.Cells(excel_row, excel_col + 24).Value
            equip_row("Section 20") = xlsmWS1.Cells(excel_row, excel_col + 25).Value

            equip_row("Section 21") = xlsmWS1.Cells(excel_row, excel_col + 26).Value
            equip_row("Section 22") = xlsmWS1.Cells(excel_row, excel_col + 27).Value
            equip_row("Section 23") = xlsmWS1.Cells(excel_row, excel_col + 28).Value
            equip_row("Section 24") = xlsmWS1.Cells(excel_row, excel_col + 29).Value
            equip_row("Section 25") = xlsmWS1.Cells(excel_row, excel_col + 30).Value
            equip_row("Section 26") = xlsmWS1.Cells(excel_row, excel_col + 31).Value

            Me.DataSet1.Equipment.Rows.Add(equip_row)
        Next

        xlsmWB1.Close()
        xlsmApp.Quit()
        xlsmApp = Nothing
        xlsmWB1 = Nothing
        xlsmWS1 = Nothing
            Exit Sub
        'ErrHandler:
        '            MsgBox("An unknown error occurred while Parsing the Excel Sheet. Sorry about that!!", vbCritical, "Error")
    End Sub


    Private Sub BindingNavigator1_RefreshItems(sender As Object, e As EventArgs) Handles BindingNavigator1.RefreshItems

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Try
            Me.Validate()
            'Me.EquipmentBindingSource.EndEdit()
            Me.EquipmentTableAdapter.Update(Me.DataSet1.Equipment)
            MsgBox("Update successful")

        Catch ex As Exception
            MsgBox("Update failed")
        End Try

    End Sub
End Class